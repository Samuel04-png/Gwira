## 2.8.1

### Fixes

- Editing a task outside the scheduling graph reschedules the project from its start
- Undo after dragging a summary task does not restore its subtasks
- The "Show conflicts" toolbar button is visible when there are no conflicts
- Community version throws an error due to progress line undefined state

## 2.8.0

### New features

- Inclusive end dates: end dates are shown as the last day of a task
- Secondary grid panel to the right of the chart | PRO feature
- Auto scheduling
  - Faster auto scheduling and bulk updates | PRO feature
  - Scheduling with all 4 link types | PRO feature
  - Constraints | PRO feature
  - Scheduling conflicts reporting UI | PRO feature
  - Deadlines | PRO feature
  - Inactive tasks | PRO feature
  - Manually scheduled tasks | PRO feature
- Timeline
  - Progress line | PRO feature
  - S-curve | PRO feature
- Data operations
  - Adding tasks via a placeholder row | PRO feature
  - Moving tasks between groups by drag and drop | PRO feature
  - Ability to add new tasks by drag-n-drop from outside components
  - The `locateTask` helper to find the task under the pointer in drag-n-drop handlers
- Resources
  - Histogram mode of the Resource load chart | PRO feature
  - Assigning resources by dragging them from the Resource load chart | PRO feature
  - Scheduling tasks by resource calendars | PRO feature
  - Export of resources and assignments | PRO feature
- Support of multi-user editing (real-time updates)

### Updates

- Simplified model of unscheduled tasks: removing the start date unschedules the task | PRO feature
- Scheduling unscheduled tasks by drag-n-drop in the chart area | PRO feature
- Preventing invalid links in the UI | PRO feature

### Fixes

- Gantt fails to load projects with long task chains
- Incorrect header height of collapsed grid
- Filtering does not work for grouped tasks
- Task updates incorrectly set `unscheduled` for summary tasks
- Drag-n-drop between groups based on duration incorrectly changes `duration`
- On load performance with state derivation and dates
- Undo/redo with auto scheduling doesn't snap to dates correctly
- Deleting branches with subtasks throws errors
- A single edit is recorded as several undo steps
- Summary task dates are stale after lazy load into a branch
- Undo does not remove fields added by an edit
- MS Project export ignores the `durationUnit` setting and treats hour durations as days
- Link lag is lost during export to and import from MS Project
- A task without its own dates takes them from its baseline on import from MS Project
- Import from MS Project treats a single baseline with any number as the primary one
- Task fields are exported to MS Project out of the MSPDI schema order
- Trim inner fields and duplicated data from the export payload
- Copying a task ignores link lag
- Clearing link lag does not reschedule tasks
- Split task segments are sometimes incorrect
- Undo after auto-scheduling moves tasks that weren't part of the change
- Provider debounce drops earlier partial task updates
- Silent summary updates do not go to the server
- Task update sends old dates after auto-scheduling
- Assignments removed on a change to summary do not go to the server
- Summary tasks are saved in the middle of task dragging
- Stale state after executing "import-tasks" or prop changes
- Zoom levels include custom scale units
- Repeated `registerScaleUnit` duplicates the unit

## 2.7.3

### Fixes

- Grid and chart rows get out of sync after indent / outdent operations

## 2.7.2

### Fixes

- Setting link lag breaks task dates
- Editor allows negative values for split tasks segments
- Undoing "delete-task" action does not restore assignments for this task
- The "copy-task" action does not copy task assignments
- The `readonly` settings does not block grid inline editors
- Initial auto scheduling pass is added to history and can be undone
- Clipboard keeps ids of deleted tasks
- Tasks after undo/redo with enabled autoscheduling don't snap to dates correctly
- History is not reset when links, resources or assignments are replaced
- History handlers are active after disabling undo/redo at run time
- Undo/redo replay triggers auto scheduling
- Context menu references the previous task
- Copy and paste of parent branches duplicates child tasks
- Grid cell padding are misaligned
- Fonts cannot be fully switched off from theme settings

## 2.7.1

### Fixes

- Better performance with links rendering
- Zoom cannot start from Resource load view
- Auto scheduling and summary `autoProgress` trigger infinite loop
- Focus on Grid header and body cells is lost / unstable
- Undo of the "move-task" action doesn't work after task was moved to a different branch
- Cell width gets a fractional value when scale start/end are set
- Newly added task is not rendered correctly after update
- `highlightTime` can be used only with day / hour minimal scale unit
- Incorrect marker position when zooming out to year scale
- After hiding a flexible column others do not adjust
- Impossible to resize Resource load columns

## 2.7.0

### New features

- Resource management | PRO feature
  - Visualizing and assigning resources | PRO feature
  - Resource load chart | PRO feature
  - Resource assignment handling in the Go backend | PRO feature
  - Grouping tasks by resources | PRO feature
  - Individual calendars for resources | PRO feature
- Individual calendars for tasks | PRO feature
- Grouping tasks by any field | PRO feature
- WBS codes | PRO feature
- Enhanced Editor UI with tabs for details
- Tooltips for links

### Updates

- Calendar JSON definition for serialization | PRO feature
- Dynamic rendering of the timescale
- Enhanced Tooltip with detailed settings
- Sticky text in scale cells to ensure that it is always visible
- Improved auto scheduling with summary tasks | PRO feature

### Fixes

- Export of tasks with calendar shows incorrect dates
- Zooming and scrolling in long scales is too slow and crashes
- Tree markers are lost after clearing filters
- Excessive `render-data` calls on horizontal scrolling
- Hover area for links is too small

### Breaking changes

- Calendar is defined not via explicit instance creation, but by plain config
- Tooltip content receives `{ api, data }` instead of `{ task, segmentIndex }

## 2.6.1

### Fixes

- Incorrect handling of rollups in Datastore
- Chart flickers during horizontal scroll and zooming

## 2.6.0

### New features

- Ability to filter data by API calls
- Ability to filter data via header filters
- Integration with SVAR Filter
- Calculating and visualizing slack | PRO feature
- Rollups | PRO feature

### Updates

- Ability to scroll to a specific date with the "scroll-chart" action
- "resize-chart" action is added to monitor widget dimensions

### Fixes

- Export to PNG/PDF: incorrect link positions
- The "scroll-chart" action does not scroll to provided coordinates
- Chart and grid are sometimes misaligned when vertical scroll appears
- Incorrect visible date during zooming
- Gantt fails to initialize in SvelteKit with server-side rendering
- API `ref` is not recognized in Typescript projects
- Task duration and start date and incorrect during drag-n-drop on some scales
- Incorrect grid width after expanding and collapsing it with all column fixed
- Narrow scale does not expand when grid is collapsed by clicking
- Tooltips are not shown for segments
- Zoom speed is too high with laptop trackpad
- Task reordering, opening and closing fails in case of integer string id

### Breaking changes

- "expand-scale" action is removed

## 2.5.2

### New features

- Server-side export to PNG, PDF, XLSX, MS Project | PRO feature
- Client-side export and import from MS Project | PRO feature
- Auto calculation of progress for summary tasks | PRO feature
- Auto conversion of parent tasks to summary tasks | PRO feature

### Fixes

- Scale is expanded left with a small dataset during screen resizing
- Markers ignore scale boundaries
- Delete link placeholder is misplaced sometimes
- Task duration and start date and incorrect during drag-n-drop on some scales

## Version 2.4.5

### Fixes

- Incorrect path to fonts and icons

## Version 2.4.4

### Fixes

- Splitting a task is limited to last segment

## Version 2.4.3

Community license changed from GPL to MIT

### Fixes

- Sourcemap included

### New features

- Basic auto scheduling | PRO feature
- Handling of invalid links | PRO feature
- Critical path calculation | PRO feature
- Global calendar to define working schedule | PRO feature
- Unscheduled tasks | PRO feature
- Vertical markers on timeline | PRO feature
- Baselines | PRO feature
- Split tasks | PRO feature
- Undo/redo | PRO feature
- Ability to remove links from Chart UI
- Locale-based scale formatting

### Updates

- Resizer line can be dragged to expand current display mode

### Fixes

- Summary task size is sometimes incorrect while dragging
- ContextMenu css cannot be set
- Editing tasks breakes dynamic width of narrow scales cells

### Breaking changes

- Scales format string is changed from date-fns to SVAR locale
- Fullscreen helper is moved to SVAR Svelte Core

## Version 2.3.4

### Fixes

- Performance regression during scrolling and zooming

## Version 2.3.3

### Fixes

- Fullscreen hotkey property should be optional
- Incorrect handling of themes
- ContextMenu custom class name cannot be set

## Version 2.3.2

### Fixes

- Tooltips for bars are not visible

## Version 2.3

### New features

- TypeScript definitions
- Ability to define "hour" duration unit
- Ability to define "minute" length unit
- Ability to create custom scale units
- `autoScale` property to configure start/end scale behaviour
- Standalone sidebar and modal Editor
- Ability to validate fields in the Editor
- Hotkeys for common actions and navigation
- Multi-sorting for table columns via the sort-tasks action
- Headermenu to hide table columns
- Inline editors for table cells
- Ability to expand/collapse table and chart via buttons

### Breaking changes

- The package migrated from wx-react-gantt to @svar-ui/react-gantt

## Version 1.3.1

### Fixes

- Rendering issues

## Version 1.3

- Released under GPLv3

## Version 1.1

### New features

- Summary tasks
- Sorting Grid columns
- Batch mode for RestDataProvider to handle mass operations

### Updates

- Common minCellwidth and maxCellWidth for zoom levels
- Skipping meaningless actions in Context Menu and Toolbar

### Fixes

- Scroll in Grid is not smooth
- Impossible to resize chart bars on the left more than for one cell
- When a branch is removed, only links of the parent task are removed
- Unstable move down behaviour: tasks are inserted in wrong positions
- Resizing columns: horizontal scrollbar does not appear
- Text of tasks is higher than a dragged bar during reordering
- Last task is misplaced after reordering when there are few tasks
- Reordering of tasks with child tasks is broken
- Impossible to define cellWidth if default zoom is enabled
- Data is removed from the task object after the "update-task" operation
- Outdenting does not work for the 3rd-level tasks
- Auto scale is calculated incorrectly if the last task is a milestone
- Parent task is not always opened after adding a new task
- Task start date is not set according to the top-level target task
- Zooming in and out between levels does not work correctly

## Version 1.0

### Initial functionality

- Fast behavior and clear API
- Configurable Grid columns
- Configurable Chart scales and cell sizes
- Task types: "project", "task", "milestone" and custom
- Baselines
- Holiday and custom markers in the Chart area
- Configurable Editor panel
- Configurable Context Menu and Toolbar
- Tooltips for tasks in the Chart area
- Readonly mode
- Fullscreen mode
- Mouse-wheel zooming in the Chart area
- Responsive behaviour of the Grid area
- Localization of labels and dates
- Ready-made DataProvider to integrate with server
